<?php

class BPC_Client { 
   private $network;

   function __construct() {
    
}
}

?>
